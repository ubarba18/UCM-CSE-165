#ifndef MYHEADER1_H_INCLUDED
#define MYHEADER1_H_INCLUDED

#include<iostream>

namespace myNameSpace {
    void fun1() {
        std::cout << "fun1 called" << std::endl;
    }
    void fun2() {
        std::cout << "fun2 called" << std::endl;
    }
}

#endif // MYHEADER1_H_INCLUDED