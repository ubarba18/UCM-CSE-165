void printError(void);
char letterExtract(char);
int sumOfTwoNum(int,int);
float floatMult(float,float);
