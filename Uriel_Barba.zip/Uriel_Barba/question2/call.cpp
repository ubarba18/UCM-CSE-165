#include <iostream>
#include"function.h"

using namespace std;

int main() {

    printError();
    sumOfTwoNum(3, 5);
    letterExtract('a');
    floatMult(3.3, 5.5);

    return 0;
}